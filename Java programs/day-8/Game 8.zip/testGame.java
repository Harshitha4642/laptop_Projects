package yathjee;
piublic class testGame{
	public static void main(String args[])
	{
		System.out.println("Welcome to Yatjee");
		Yatjee y = new Yatjee();
		y.computeScore();
	}
}