package yatjeeDBMS;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
public class Yatjee {
	private int[] values;
	private ArrayList<Integer> scores = new ArrayList<Integer>();
	private static final double[] average= {0.00 ,1.88, 5.28, 8.57, 12.16, 15.69, 19.19, 21.66,
			13.10, 22.59, 29.46, 32.71, 16.87, 22.01};
	public static final String[] categories = {" ", "aces", "twos", "threes", "fours", "fives", 
			"sixes", "three of a kind", "four of a kind", "full house", "small straight",
			"large staright", "yahtzee", "chance"};

	private int[] diceRoll()
	{
		Random rand = new Random();
		int values[]= new int[5];
		for(int i=0; i<5; i++)
		{
			values[i]=rand.nextInt(1,6);
		}
		System.out.print("\nDice outcomes: ");
		for(int i=0; i<5; i++)
		{
			System.out.print(values[i]+" ");
		}
		System.out.println("\n");
		
		return(values);
	}
	
	public ArrayList<Integer> computeScore() {	
		scores.add(0);
		values = diceRoll();
		Arrays.sort(values);
		aceTosixes();
		threeOfKind();
		fourOfKind();
		fullHouse();
		smallStraight();
		largeStraight();
		yahtjee();
		chance();
		
		return scores;
		
	}
		private void aceTosixes() {
			int variable=1;
			while(variable<=6)
			{
				int score = 0;
				for(int var=0; var<values.length; var++)
				{
					if( values[var] == variable)
					{
						score = score + variable;
					}
				}
				variable++;
				scores.add(score);
				
			}
		}
		private void threeOfKind()
		{
			int i;
			for(i=0; i < values.length; i++)
			{
				if(count(values[i]) == 3) {
					scores.add(sum());
					break;
				}	
			}
			if(i==values.length)
				scores.add(0);
		}
		
		private void fourOfKind()
		{
			int i;
			for(i=0; i < values.length; i++)
			{
				if(count(values[i]) == 4) {
					scores.add(sum());
					break;
				}
			}
			if(i==values.length)
				scores.add(0);
			
		}
		
		private void fullHouse()
		{
			if (count(values[0])==2 && count(values[4]) ==3 )
			     scores.add(25);
			else if((count(values[0]) == 3  && count(values[4]) == 2))
				scores.add(25);
			else
				scores.add(0);
		}
		private void smallStraight()
		{
			if((count(1)>0 && count(2)>0 && count(3)>0 && count(4)>0) || 
					(count(2)>0 && count(3)>0 && count(4)>0 && count(5)>0) ||
					(count(3)>0 && count(4)>0 && count(5)>0 && count(6)>0) )
				scores.add(30);
			
			else {
				scores.add(0);
			}
		}
		private void largeStraight()
		{
			if((count(1)>0 && count(2)>0 && count(3)>0 && count(4)>0 && count(5)>0 ) || 
					(count(2)>0 && count(3)>0 && count(4)>0 && count(5)>0&& count(6)>0 ))
				scores.add(40);
			else 
				scores.add(0);
		}
		
		private void yahtjee()
		{
			if(count(values[0])==5)
				scores.add(50);
			else
				scores.add(0);
		}
		
		private void chance() {
			scores.add(sum());
		}	
	
	private int count(int x)
	{
		int var=0;
		for(int i : values)
			if(i == x)
				var++;
		return var;
	}
	
	private int sum()
	{
		int sum=0;
		for(int i=0;i<values.length; i++)
		{
			sum = sum + values[i];
		}
		return(sum);
	}
}