use yatjeeScores

create table scores(id int primary key, 
aces int, 
twos int, 
threes int, 
fours int, 
fives int, 
sixes int, 
three_of_kind int, 
four_of_kind int, 
full_house int, 
small_straight int, 
large_straight int, 
yatjee int, 
chance int
);
commit;
