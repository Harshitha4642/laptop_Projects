package yatjeeDBMS;

import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class TestYatjee {
	public static void main(String args[]) throws SQLException {
		PreparedStatement exupdate = null;
		try {
			Connection connection = null;
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/yatjeeScores","Harshitha", "harshitha@123");
			String update = "insert into scores (id, aces,twos, threes, fours, fives, sixes, three_of_kind, four_of_kind, full_house, small_straight, large_straight, yatjee, chance) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?);";
			exupdate = connection.prepareStatement(update);
		}
		catch(Exception e){
			System.out.println(e);
		}
		
		Scanner sc = new Scanner(System.in);
		int index,i,var=0;
		Integer e;
		ArrayList <Integer> final_scores = new ArrayList<Integer>(13);
		ArrayList <Boolean> block = new ArrayList<Boolean>();
		ArrayList <Integer> scores = new ArrayList<Integer>();
		for(int temp=0; temp <= 13; temp++)
		{
			final_scores.add(0);
		}
		for(int k=0;k<=13;k++)
			block.add(true);
				
		System.out.println("Welcome to Yatjee\n");
		
		while(var<13) {
			Yatjee y = new Yatjee();
			scores = y.computeScore();
			System.out.print(var+1+") ");
			System.out.println("All possible scores for this outcome");
			for(int temp=1; temp <= 13; temp++)
			{
				System.out.println((temp)+". "+y.categories[temp]+" : "+scores.get(temp));
			}
			
			System.out.println("Enter the index in which you want to enter score ");
			index = sc.nextInt();
			
			if(block.get(index))
			{
				e = (Integer) scores.get(index);
				final_scores.set(index,e);
				block.set(index,false);
			}
			else
			{
				System.out.println("Can't modify");
			}
			System.out.println("var:"+var);
			exupdate.setInt(1,var+1);
			for(int g=1;g<=final_scores.size()-1;g++)
			{
				
				System.out.println(g+1);
				exupdate.setInt(g+1,final_scores.get(g));
				
			}
			exupdate.executeUpdate();
			var++;
		}
		
	
	}
}
