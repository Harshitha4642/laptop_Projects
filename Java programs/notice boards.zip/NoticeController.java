package websites;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class NoticeController {
	NoticeController n;
	Connection connection;
	PreparedStatement stmt; 
	Statement stmt1;
	public NoticeController()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/NoticeBoard","Harshitha", "harshitha@123");	
		}
		catch(Exception e){
			System.out.println("I could not get connected");
		}	
	}
	
	public void takeNoticeContents(int noticeID, String noticeName, String noticeContents) throws SQLException
	{
		String select = "select count(*) as countOf from notices";
		stmt1 = connection.createStatement();
		ResultSet rs = stmt1.executeQuery(select);
		rs.next();
		int count = rs.getInt("countOf");
		if(count<6) 
		{
			String update="insert into notices values(?,?,?);";
			stmt = connection.prepareStatement(update);
			stmt.setInt(1, noticeID);
			stmt.setString(2,noticeName);
			stmt.setString(3, noticeContents);
			int rows = stmt.executeUpdate();
		}
		else if(count>=6)
		{
			String stat = "update notices set id="+(noticeID%6)+", name= "+'"'+noticeName+'"'+", content = "+'"'+noticeContents+'"'+" where id ="+ (noticeID%6)+";";
			System.out.println(stat);
			stmt1 = connection.createStatement();
			int rows = stmt1.executeUpdate(stat);
			if(rows>0)
			{
				System.out.println("success");
			}
			else
			{
				System.out.println("failure");
			}
		}
	}
	
	public StringBuffer getUpdatedNoticeBoard() throws SQLException
	{
		String select = "select * from notices;";
		stmt1 = connection.createStatement();
		ResultSet rs = stmt1.executeQuery(select);
		StringBuffer noticeBoard = new StringBuffer();
		while(rs.next())
		{
			noticeBoard.append(rs.getInt("id")+" "+rs.getString("name")+" "+rs.getString("content")+"     ");
			noticeBoard.append("    ");
		}
		return noticeBoard;	
	}	
}

