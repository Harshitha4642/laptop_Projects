package websites;

import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;

import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.WebApplicationTemplateResolver;
import org.thymeleaf.web.IWebExchange;
import org.thymeleaf.web.servlet.JakartaServletWebApplication;
@WebServlet("/noticetaker")
public class NoticeTaker extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private JakartaServletWebApplication application;
    private TemplateEngine templateEngine;
    StringBuffer notice_board;
    
    public NoticeTaker() {
        super();
    }
    
    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        
        application = JakartaServletWebApplication.buildApplication(getServletContext());
        final WebApplicationTemplateResolver templateResolver = 
            new WebApplicationTemplateResolver(application);
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateResolver.setPrefix("/WEB-INF/templates/");
        templateResolver.setSuffix(".html");
        templateEngine = new TemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);
      }
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		var out1 = response.getWriter();
		 final IWebExchange webExchange = 
			        this.application.buildExchange(request, response);
		final WebContext ctx = new WebContext(webExchange);
		templateEngine.process("notice", ctx, out1);
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		var out = response.getWriter();
	    final IWebExchange webExchange = 
	        this.application.buildExchange(request, response);
	    final WebContext ctx = new WebContext(webExchange);
	    
	    int noticeID;
	    String noticeName;
	    String noticeContent;
	    NoticeController controller = new NoticeController();
	    
	    if("Add".equals(request.getParameter("submit")))
	    {
	    	noticeID = Integer.valueOf(request.getParameter("notice_id"));
	    	noticeName = request.getParameter("notice_name");
	    	noticeContent = request.getParameter("notice_content");
	    	try {
				controller.takeNoticeContents(noticeID,noticeName, noticeContent);
			} catch (SQLException e) {
				e.printStackTrace();
			}	    	
	    }
	    
	    else if("Display".equals(request.getParameter("display")))
	    {
	    	try {
				notice_board = controller.getUpdatedNoticeBoard();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	    	ctx.setVariable("noticeBoard",notice_board);
	    }
	    templateEngine.process("notice", ctx, out);
	}

}
