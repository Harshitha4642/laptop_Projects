package wordle;
import java.util.Scanner;
public class main {
	public static void main (String[] args)
	{
		Wordle word = new Wordle();
		Scanner sc = new Scanner(System.in);
		String newWord = "";
		System.out.println("Welcome to wordle");
		System.out.println("Think of a word in your mind");
		String guessedWord = word.guess();
		System.out.println("The word is " + guessedWord);
		for(int num=0; num<6; num++)
		{
			String result = sc.next();
			
			if(word.isCorrect(result)) {
				System.out.println("The correct word is: "+ newWord);
				break;
			}
			
			else if(word.isWrong(result))
				System.out.println("The word is: "+ word.guess());
			
			else 
			{
				String sameLetters = word.checkSameLetters(result, guessedWord);
				newWord = word.getWord(sameLetters, guessedWord);
				System.out.println("My guess is: "+newWord);
			}
			
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		System.out.println("Guess a word in your mind");
		String guessedWord = word.guess(); 
		System.out.println("1st chance: " + guessedWord);
		String result = sc.next();
		if(word.isCorrect(result))
			System.out.println("The word is: "+ guessedWord);
		else if(word.isWrong(result))
			System.out.println(word.guess());
		else 
		{
			String sameLetters = word.checkSameLetters(result, guessedWord);
			//System.out.println(sameLetters);
			String newWord = word.getWord(sameLetters, guessedWord);
			System.out.println("My guess is: "+newWord);
		}
		//System.out.println(word.has("harshitha","ra"));
			*/
		sc.close();
	}
	

}
