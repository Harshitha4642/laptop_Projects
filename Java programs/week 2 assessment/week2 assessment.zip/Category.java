package trumpCards;

public class Category {
	public String name;
	public int[] values = new int[7];
	String categories[] = {"matches", "not outs", "runs", "high score", 
			"average", "hundreds", "fifties","ACC ranking"};
	public double average;
	
}
