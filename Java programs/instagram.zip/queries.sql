create table teams(
	id int primary key, 
	team text 
);

create table players(
	playerId int, 
	name text, 
	team text, 
	id references teams(id)
);

CREATE TABLE matches(
	id INTEGER PRIMARY_KEY,
	matchday TEXT,
	home_team_id INTEGER NOT NULL,
	away_team_id INTEGER NOT NULL,
	venue TEXT,
	player_of_the_match_id INTEGER NOT NULL
);

insert into Teams values(1,"india");
insert into Teams values(2,"usa");
insert into Teams values(3,"africa");
insert into Teams values(4,"argentina");

insert into Players values(1,"abc","india",1);
insert into Players values(2,"def","india",1);
insert into Players values(3,"jdd","usa",2);
insert into Players values(4,"mdk","usa",2);
insert into Players values(5,"dmd","africa",3);
insert into Players values(6,"ksl","africa",3);
insert into Players values(7,"wkw","argentina",4);
insert into Players values(8,"mcw","argentina",4);

insert into matches values(1,"23/06/2023",1,2,"alaska",1);
insert into matches values(2,"24/06/2023",1,3,"alaska",2);
insert into matches values(3,"25/06/2023",1,4,"alaska",1);
insert into matches values(4,"26/06/2023",2,3,"alaska",5);
insert into matches values(5,"27/06/2023",2,4,"alaska",6);
insert into matches values(6,"28/06/2023",3,4,"alaska",8);

select
* from matches 
where player_of_the_match_id in 
(
	select playerId from players 
	where id=1 or id=2
);

select 
player_of_the_match_id as "player of match", 
name as "Name" from matches, players 
where 
matches.player_of_the_match_id = players.playerId;

select 
team as "Country", 
playerId as "player id" from matches, players 
where 
matches.player_of_the_match_id = players.playerId;

