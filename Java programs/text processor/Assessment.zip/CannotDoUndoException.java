package textProcessor;

public class CannotDoUndoException extends Exception {

	private static final long serialVersionUID = 1L;
	public CannotDoUndoException(String s)
	{
	super(s);
	}

}
