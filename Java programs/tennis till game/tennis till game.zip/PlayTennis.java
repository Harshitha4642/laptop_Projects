package tennis;
import java.util.*;
public class PlayTennis {

	public void Gamewin()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter true if player missed the serve,\nif player sucessfully utilize their serve, then enter false");
		
		System.out.println("Enter the name of Player 1: ");
		Player player1 = new Player(sc.next(),0);
		
		System.out.println("Enter the name of Player 2: ");
		Player player2 = new Player(sc.next(),0);
		
		
		boolean player1Missed, player2Missed;
		Game game = new Game(player1, player2);
		Player winner = null;
		while(winner==null) {
			System.out.println("Enter the serve, \nenter boolean value, the press enter and again enter the boolean value");
			player1Missed = sc.nextBoolean();
			player2Missed = sc.nextBoolean();
			Serve serve = new Serve(player1Missed, player2Missed);
			game.updateScoreBoard(serve);
			System.out.println("Score Board is: \n"+game.getScoreBoard());
			winner = game.hasWinner();
		}

		if(winner!=null)
		{
			System.out.println("Winner is "+winner.name);
		}
		sc.close();	
	}
	
	
	public static void main(String args[])
	{
		PlayTennis p =new PlayTennis();
		p.Gamewin();
	}

}
