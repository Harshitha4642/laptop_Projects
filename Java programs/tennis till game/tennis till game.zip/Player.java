package tennis;

public class Player {
	String name;
	int score;
	
	public Player() {}
	
	public Player(String name, int score)
	{
		this.name = name;
		this.score = score;
	}
}
