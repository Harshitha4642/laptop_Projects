package com.prodapt.cycles.rent;

public class UserService {
	/*
	cycleRepository.restockCyclesOfID(restockId.get());
	cycleRepository.clearCyclesOfID(restockId.get());
	model.addAttribute("message", "restock done");
	*/

}
